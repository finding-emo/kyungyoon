import os

installpath = os.path.sep.join(
    os.path.dirname(os.path.realpath(__file__)).split(os.path.sep)[:-1])

ADJECTIVE = 'Adjective'
VERB = 'Verb'
EOMI = 'Eomi'